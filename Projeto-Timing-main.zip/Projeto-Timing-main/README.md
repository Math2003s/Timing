# Timing
Projeto Interdisciplinar (projeto facultativo) que consiste em criar um software de gestão de horários e tarefas feito em Java usando a interface gráfica WindowBuilder, com o objetivo de solucionar o problema de gestão de tempo das pessoas.

# Requisitos
Para o software funcionar corretamente é necessário importar o connector do banco de dados e criar.
O script do banco de dados está na pasta bin.
